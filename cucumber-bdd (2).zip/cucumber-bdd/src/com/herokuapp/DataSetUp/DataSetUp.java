package com.herokuapp.DataSetUp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import com.herokuapp.PageObjectModel.*;
import com.herokuapp.TestRunner.*;

public class DataSetUp {
	public static String strBrowserType,strURL,strCanvasEle,strFirstbtn,stralertbtn,strSuccessbtn,strHeadLessExecution,strPropertyFilePath;
	public static String strhearderrow,strGblTestStep,strGblStepAction,strResultFolder=null,strScreenShotMainFolderName=null,strrowofthetabel;
	
public static void fnReadPropertiesFileData()
	{
		try
		{
		
			Properties prop = new Properties();
		    InputStream input = null;
		    strPropertyFilePath = ".//resources//ObjectRepository.properties";
		
				
						
				input = new FileInputStream(strPropertyFilePath);		
				
				
				// load a properties file
				prop.load(input);
				// Common.java
				//Config Data
				strBrowserType = prop.getProperty("Config.Browser");
				strURL = prop.getProperty("Config.URL");
				strHeadLessExecution = prop.getProperty("Config.HeadLessExecutionSwitch");
				
				strCanvasEle = prop.getProperty("mainpage.canvas");
				strFirstbtn = prop.getProperty("mainpage.firstbutton");
				stralertbtn = prop.getProperty("mainpage.alertbutton");
				strSuccessbtn = prop.getProperty("mainpage.successbutton");
				strrowofthetabel = prop.getProperty("mainpage.rowofthetable");
				strhearderrow = prop.getProperty("mainpage.tblheader");			
				
				
		   }catch (Exception e){
            System.out.println("error "+e);
        }
	}


}
