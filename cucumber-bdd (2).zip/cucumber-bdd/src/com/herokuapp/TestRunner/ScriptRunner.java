package com.herokuapp.TestRunner;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.herokuapp.DataSetUp.DataSetUp;
import com.herokuapp.PageObjectModel.Common;

import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.testng.AbstractTestNGCucumberTests;


@CucumberOptions(features="Features",format = {"json:target/cucumber.json","html:target/site/cucumber-pretty"},plugin = {"pretty","html:target/site/cucumber-pretty","json:target/cucumber/cucumber.json"},glue={"com.herokuapp.StepDefinition"})

public class ScriptRunner extends AbstractTestNGCucumberTests {

	
	@BeforeSuite
	@Parameters({"tags"})
	public static void fnDataCofiguration(String tags)
	{	
		String strTags = "@"+tags;
		System.setProperty("cucumber.options","-t "+strTags);			
		DataSetUp.strResultFolder = ".\\results\\"+Common.fngetDateAndTime("ddMMMyy_hh_mm");
		Common.fnCreateFolder(DataSetUp.strResultFolder);
		DataSetUp.strScreenShotMainFolderName = DataSetUp.strResultFolder+"\\ScreenShots";
		Common.fnCreateFolder(DataSetUp.strScreenShotMainFolderName);
		DataSetUp.fnReadPropertiesFileData();
		
	}
	
	/*	
	@BeforeTest
	public static void fnDataconfiguration()
	{
		DataSetUp.fnReadPropertiesFileData();			
				
	}
	*/

	

}
