package com.herokuapp.PageObjectModel;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class mainpage extends Common{
	
	@Test
	public static void fnClickChallengeButton(String strbtnName)
	{
		 try
		  
		  {
								 
			 switch (strbtnName) {
			 
				case "First":					
								
					fnGetWebElement(strFirstbtn,10).click();	
										
					fnTakeScreenshot("Firstbutton"); 
					fnwriteLogs("[Button click] First button click | Passed |");
					break;

				case "Alert":					
					
					fnGetWebElement(stralertbtn,10).click();
					fnTakeScreenshot("Alter button");
					fnwriteLogs("[ Button Click ] Alter button click | Passed |");
					break;

				case "Success":							
					//New SIMO React page
					fnGetWebElement(strSuccessbtn,10).click();					
					fnTakeScreenshot("success button");
					fnwriteLogs("[ Button Click ] Success button | Passed |");
					break;	
									
				}  
			 
			   			    
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Challenge Button Failed");
	             fnwriteLogs("[ Button Click ] Button not found | Failed |");
	           
	             
	        }
	    
	}
	
	
	@Test
	public static void fnVerifyCanvas()
	{
		 try
		  
		  {
			
			fnGetWebElement(strCanvasEle,10);
			fnwriteLogs("[ Canvas verification ] Answer canvas is present | Passed |");
			   			    
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Challenge Button Failed");
	             fnwriteLogs("[ Canvas verification ] Answer canvas not present | Failed |");
	           
	             
	        }
	    
	}
	
	@Test
	public static void fnVerifyButtonText(String strbutton,String strtext1,String strtext2,String strtext3,String strtext4)
	{
		 try
		  
		  {
			 String strBtnText=null;
			
			 switch (strbutton) {
			 
				case "First":					
								
					strBtnText = fnGetWebElement(strFirstbtn,10).getText();	
										
					fnTakeScreenshot("Firstbutton"); 
					fnwriteLogs("[Button get text] First button | Passed |");
					break;

				case "Alert":					
					
					strBtnText = fnGetWebElement(stralertbtn,10).getText();
					fnTakeScreenshot("Alter button");
					fnwriteLogs("[ Button get text ] Alter button | Passed |");
					break;

				case "Success":							
					
					strBtnText = fnGetWebElement(strSuccessbtn,10).getText();					
					fnTakeScreenshot("success button");
					fnwriteLogs("[ Button get text ] Success button| Passed |");
					break;	
									
				}  
			 
			 strBtnText = strBtnText.trim();
			 			 
			 if(!(strBtnText.equalsIgnoreCase(strtext1)) && !(strBtnText.equalsIgnoreCase(strtext2)) && !(strBtnText.equalsIgnoreCase(strtext3)) && !(strBtnText.equalsIgnoreCase(strtext4))) {
				 Assert.fail("Wrong button " + strBtnText);
			 }
			   			    
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Challenge Button Failed");
	             fnwriteLogs("[ Button get text ] Button not found | Failed |");
	           
	             
	        }
	    
	}
	

	@Test
	public static void fnClickEditBtn(String strRowNumber)
	{
		 try
		  
		  {
			
			fnGetWebElement("//table//tr["+strRowNumber+"]/td[7]/a[text()='edit']",10).click();
			   			    
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Challenge Button Failed");
	             fnwriteLogs("[ Button Click ] Edit button not found | Failed |");
	           
	             
	        }
	    
	}
	
	@Test
	public static void fnClickDeleteBtn(String strRowNumber)
	{
		 try
		  
		  {
			
			fnGetWebElement("//table//tr["+strRowNumber+"]/td[7]/a[text()='delete']",10).click();
			   			    
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Challenge Button Failed");
	             fnwriteLogs("[ Button Click ] deleted button not found | Failed |");
	           
	             
	        }
	    
	}
	
	@Test
	public static void fnVerifyURL(String strbtnName)
	{
		 try
		  
		  {
			 
			 
								 
			 switch (strbtnName) {
			 
				case "Edit":	
					
					String getedURL =  driver.getCurrentUrl();										
					Assert.assertTrue(getedURL.contains("edit"), "Incorrect edit page URL");					
					fnTakeScreenshot("EditURL"); 
					fnwriteLogs("[Verify URL] Edit URL | Passed |");
					break;

				case "Delete":					
					
					String getdelURL =  driver.getCurrentUrl();										
					Assert.assertTrue(getdelURL.contains("delete"), "Incorrect delete page URL");	
					fnTakeScreenshot("DeleteURL");
					fnwriteLogs("[ Verify URL ] delete url | Passed |");
					break;

				case "Main":							
					String getmainURL =  driver.getCurrentUrl();										
					Assert.assertTrue(getmainURL.equalsIgnoreCase("https://the-internet.herokuapp.com/challenging_dom"), "Incorrect delete page URL");				
					fnTakeScreenshot("main url");
					fnwriteLogs("[ Verify URL ] main url | Passed |");
					break;	
									
				}  
			 
			   			    
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Verify URL");
	             fnwriteLogs("[ Verify URL ] URL Verifcation | Failed |");
	           
	             
	        }
	    
	}
	
	@Test
	public static void fnVerifyParagrphText()
	{
		 try
		  
		  {
			
			String strParaTxt = fnGetWebElement("//p",10).getText();
			Assert.assertTrue(strParaTxt.equalsIgnoreCase("The hardest part in automated web testing is finding the best locators (e.g., ones that well named, unique, and unlikely to change). It's more often than not that the application you're testing was not built with this concept in mind. This example demonstrates that with unique IDs, a table with no helpful locators, and a canvas element."), "Expected paragraph not found");
			   			    
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Verify Paragrph");
	             fnwriteLogs("[ Verify Text ] Verify Paragraph text | Failed |");
	           
	             
	        }
	    
	}
	
	@Test
	public static void fnVerifyTableRowCount(String strrowcount)
	{
		 try
		  
		  {
			
			 int introwcount =  Integer.parseInt(strrowcount);
			 
			List<WebElement> webelrowoftable = driver.findElements(By.xpath(strrowofthetabel));			
			Assert.assertTrue(webelrowoftable.size() == introwcount,"Number of rows is not correct");
					
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Verify table row");
	             fnwriteLogs("[ Verify table row ] Count the number of rows in the table | Failed |");
	           
	             
	        }
	    
	}
	
	@Test
	public static void fnVerifyTableColoumnCount(String strcolcount)
	{
		 try
		  
		  {
			
			 int intcolcount =  Integer.parseInt(strcolcount);
			 
			List<WebElement> webelrowoftable = driver.findElements(By.xpath(strrowofthetabel+"[1]/td"));			
			Assert.assertTrue(webelrowoftable.size() == intcolcount,"Number of coloumn is not correct");
					
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Verify table col");
	             fnwriteLogs("[ Verify table coloumn ] count the number of coloumn | Failed |");
	           
	             
	        }
	    
	}

	
	@Test
	public static void fnVerifyTableHeader(String strcolno,String strheadertext)
	{
		 try
		  
		  {
			
				 
			 String strgetHeadertext = fnGetWebElement(strhearderrow+"["+strcolno+"]",10).getText();
			 				
			 Assert.assertTrue(strgetHeadertext.equalsIgnoreCase(strheadertext),"Number of coloumn is not correct");
					
		  }catch (Exception e){
	             System.out.println("error "+e);
	             fnTakeScreenshot("Verify table row");
	             fnwriteLogs("[ Verify table header ] Table header verfication | Failed |");
	           
	             
	        }
	    
	}

	
		
		
		
}
