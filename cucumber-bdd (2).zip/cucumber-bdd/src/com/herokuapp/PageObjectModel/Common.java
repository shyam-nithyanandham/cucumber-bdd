package com.herokuapp.PageObjectModel;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.RemoteExecuteMethod;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.herokuapp.DataSetUp.DataSetUp;
import com.herokuapp.TestRunner.*;
import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.model.Job;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;

import cucumber.api.java.After;


public class Common extends DataSetUp{
	
	
public static RemoteWebDriver driver;
static File file;

	
@SuppressWarnings("deprecation")
@Test
	public static void fnLaunchLandingPage() throws EncryptedDocumentException, InvalidFormatException, IOException
	{
	
	try{
		
				
		switch (strBrowserType) {
		case "Chrome":
			System.setProperty("webdriver.chrome.driver", ".\\lib\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();		
			options.addArguments("ChromelessOptions");
			if(strHeadLessExecution.equalsIgnoreCase("On"))
			{		
			options.addArguments("headless");
			options.addArguments("window-size=1800x900");
			}
			else
			{
				options.addArguments("start-maximized");
			}				
			options.addArguments("--incognito");
			
			DesiredCapabilities capabilities2 = DesiredCapabilities.chrome();
			    
			capabilities2.setCapability(ChromeOptions.CAPABILITY, options);		
			driver = new ChromeDriver(capabilities2);
			driver.manage().deleteAllCookies();
			fnwriteLogs(" [Launch browser ] Launched the chrome browser | Passed |");		
			break;	
			
		case "IExplorer":
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability("ignoreZoomSetting", true);
			File file = new File(".\\lib\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			driver = new InternetExplorerDriver(capabilities);
			fnwriteLogs("[ Launch browser ] Launched the IE browser | Passed |");		
			break;
					
		   }
	    
		driver.get(strURL);
    
	   }
	catch (Exception e)
	{
		fnwriteLogs("[ Invoke URL ] Issue in openting the URL, execption is  "+e.getMessage() +"| Failed |");	
	}
}
	

	public static String fngetDateAndTime(String strDateFromat)
	{		
		DateFormat dateFormat = new SimpleDateFormat(strDateFromat);
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	public static void fnCreateFolder(String strPath)
	{		
		File dir = new File(strPath);
		dir.mkdir();
	}
	
	public static String fnTakeScreenshot(String strText)
	{
		String strPath = null,timeStamp;
		File screenShotName;		
		try {
			
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()); 
		screenShotName = new File(strScreenShotMainFolderName+"//"+timeStamp+strText+".png");
		FileUtils.copyFile(scrFile, screenShotName);
		strPath = "..//ScreenShot//"+timeStamp+".png";
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return strPath;
	}	
	
	
	
	public static String fnwriteLogs(String strDes)
	{
		String strPath = null;
		try {
			
		strDes = fngetDateAndTime("dd-MMM-YY HH:mm:ss")+" "+strDes;
			
		strPath= strScreenShotMainFolderName+"//Log.txt";
        file = new File(strPath);
        // If file doesn't exists, then create it
        if (!file.exists()) {
            file.createNewFile();
        }
		
		FileWriter fw = new FileWriter(file.getAbsoluteFile(),true);
        BufferedWriter bw = new BufferedWriter(fw);

        // Write in file
        bw.newLine();
        bw.write(strDes);
        
        System.out.println(strDes);

        // Close connection
        bw.close();
		
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return strPath;
	}

	
	@Test
	public static void fnCloseTheBrowser()	
	{		
		
		driver.close();
		driver.quit();	
	}
	
	
	@Test
	public static WebElement fnGetWebElement(String srtLocator,int intTimeout)	
	{	
		WebElement webelement = null;
		try
		{     
			 WebDriverWait wait = new WebDriverWait(driver, intTimeout);	
			 webelement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(srtLocator)));			 
			 
		}
		catch(TimeoutException  e)
		{
			fnwriteLogs("[ Find Element ] Unable to find the element "+srtLocator+ " | Failed |");
			e.printStackTrace();
			
		}
		
		return webelement;
	
	}
	
	
	
}
