package com.herokuapp.StepDefinition;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.exec.launcher.Java13CommandLauncher;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.herokuapp.DataSetUp.DataSetUp;
import com.herokuapp.PageObjectModel.*;

import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition extends mainpage{
	
	
	@Given("^I want to launch the herokuapp$")
	public void i_want_to_launch_the_herokuapp() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		fnLaunchLandingPage();
	}
	
	@Given("^I want click the \"([^\"]*)\" button$")
	public void i_want_click_the_button(String strButton) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    fnClickChallengeButton(strButton);
	}
	
	@Then("^I want to verify canvas$")
	public void i_want_to_verify_canvas() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    fnVerifyCanvas();
	}

	
	@Then("^I want to verify \"([^\"]*)\" button text \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" or \"([^\"]*)\"$")
	public void i_want_to_verify_button_text_or(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 fnVerifyButtonText(arg1,arg2,arg3,arg4,arg5);
	}
	
	@Given("^I want to click the edit button in row \"([^\"]*)\"$")
	public void i_want_to_click_the_edit_button_in_row(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    fnClickEditBtn(arg1);
	}
	
	@Then("^I want to verify the page url contains \"([^\"]*)\"$")
	public void i_want_to_verify_the_page_url_contains(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		fnVerifyURL(arg1);
	}
	
	@Given("^I want to click the delete button in row \"([^\"]*)\"$")
	public void i_want_to_click_the_delete_button_in_row(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    fnClickDeleteBtn(arg1);
	}
	
	
	@Given("^I want to verify text in paragraph$")
	public void i_want_to_verify_text_in_paragraph() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    fnVerifyParagrphText();
	}
	
	@Given("^I want to verify the table should contain \"([^\"]*)\" rows$")
	public void i_want_to_verify_the_table_should_contain_rows(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    fnVerifyTableRowCount(arg1);
	}

	@Then("^I want to verify the table should contain \"([^\"]*)\" coloumn$")
	public void i_want_to_verify_the_table_should_contain_coloumn(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    fnVerifyTableColoumnCount(arg1);
	}

	@Then("^I want to verify \"([^\"]*)\" coloumn of header is \"([^\"]*)\"$")
	public void i_want_to_verify_coloumn_of_header_is(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		fnVerifyTableHeader(arg1,arg2);
	}

	   
	@After
	public void teardown()
	{
		fnCloseTheBrowser();
	}
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<< End Of Page >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	
} //End of Class

